﻿namespace Authentication;

public class AuthenticationResponse
{
    public string JwtToken { get; set; } = string.Empty;
}
